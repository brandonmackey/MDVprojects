//
//  FirstViewController.m
//  MDF-Wk3
//
//  Created by Brandon Mackey on 8/21/13.
//  Copyright (c) 2013 Brandon Mackey. All rights reserved.
//

#import "FirstViewController.h"
#import "MyMapAnnotation.h"
#import "CustomViewController.h"
#import "CustomTableCell.h"

@interface FirstViewController ()

@end

@implementation FirstViewController
@synthesize listData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"First", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    stringArray = [[NSMutableArray alloc]initWithObjects:@"Taco Bell", @"McDonals",@"Taco Bell", nil];
    
    // MUTABLE ARRAY FOR DETAILED VIEW
    
    //CODE HERE!!!!!
    myBiz = [[NSMutableArray alloc] initWithObjects:@"Taco Bell Noblesville, IN",@"McDonals Cicero, IN", nil];
    
    self.listData = [Singleton GetInstance];
    
    doneButton.hidden = true;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(IBAction)onEdit:(id)sender
{
    UIButton *button = (UIButton*)sender;
    if (button !=nil)
    {
        if (button.tag == 0)
        {
            [tableView setEditing:true];
            doneButton.hidden = false;
        }
        else if (button.tag == 1)
        {
            [tableView setEditing:false];
            doneButton.hidden = true;
        }
    }
}

#pragma mark - TableView Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // No Matter how many Cells I have this will count them
    return stringArray.count;
}

// EDIT AND DELETE METHOD

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}



- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // DELETE MODE
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        NSLog(@"WE WANT TO DELETE ROW=%d", indexPath.row);
        
        // REMOVES OBJECT FROM THE LIST
        [stringArray removeObjectAtIndex:indexPath.row];
        
        [self->tableView deleteRowsAtIndexPaths:[NSMutableArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView2 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    cell =[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[CustomTableCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    
//    NSUInteger row = [indexPath row];
//        cell.textLabel.text = [stringArray objectAtIndex:row];
    
    
    
    
        NSArray* views = [[NSBundle mainBundle] loadNibNamed:@"CustomCellView" owner:nil options:nil];
    
            for (UIView *view in views)
            {
                if ([view isKindOfClass:[CustomTableCell class]])
                {
                    cell = (CustomTableCell*)view;
    
                    cell.textLabel.text = [stringArray objectAtIndex:indexPath.row];
                }
            }
    
    
    
    
        static int count =0;
        cell.textLabel.text = (NSString*)[stringArray objectAtIndex:indexPath.row];
    
        count++;
    return cell;
}

// DETAILED VIEW METHOD

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomViewController *detailView = [[CustomViewController alloc] initWithNibName:@"CustomViewController" bundle:nil];
    if (detailView !=nil)
    {
        [self presentViewController:detailView animated:true completion:nil];
        
        //detailView.biz.text = [myBiz objectAtIndex:indexPath.row];
        //detailView.price.text = [myPrice objectAtIndex:indexPath.row];
    }
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
