//
//  Singleton.m
//  MDF-Wk3
//
//  Created by Brandon Mackey on 8/22/13.
//  Copyright (c) 2013 Brandon Mackey. All rights reserved.
//

#import "Singleton.h"
#import "MyMapAnnotation.h"
#import "SecondViewController.h"

@implementation Singleton

static Singleton *_instance = nil;

+(Singleton*)GetInstance
{
    if (_instance == nil)
    {
        [[self alloc]init];
    }
    return _instance;
}

-(id)alloc
{
    _instance = [super alloc];
    
    return _instance;
}



-(id)init
{
    if (self = [super init])
    {
//        self.stringArray = [[NSMutableArray alloc]initWithObjects:
//                            @{@"Taco Bell":@"Noblesville"}, nil];

    }
    return self;
}

@end
