//
//  CustomViewController.h
//  MDF-Wk3
//
//  Created by Brandon Mackey on 8/21/13.
//  Copyright (c) 2013 Brandon Mackey. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FirstViewController.h"
#import <MapKit/MapKit.h>

@interface CustomViewController : UIViewController
{
    IBOutlet UIButton *backButton;
    IBOutlet MKMapView *mapView;
}

-(IBAction)onClose:(id)sender;

@property (nonatomic, strong) UILabel *biz;

@end



//Need @property for detailed view items